//
//  HomeTopView.h
//  小红书
//
//  Created by apple on 16/2/22.
//  Copyright © 2016年 Norman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTopView : UIView<UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@end
