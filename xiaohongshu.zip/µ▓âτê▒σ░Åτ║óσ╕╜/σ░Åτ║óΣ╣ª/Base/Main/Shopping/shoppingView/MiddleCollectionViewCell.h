//
//  MiddleCollectionViewCell.h
//  小红书
//
//  Created by Apple on 16/2/12.
//  Copyright © 2016年 zjj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MiddleCollectionViewCell : UICollectionViewCell

@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) UILabel *label;

@end
