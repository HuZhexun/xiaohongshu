//
//  ListCollModel.m
//  小红书
//
//  Created by Apple on 16/2/22.
//  Copyright © 2016年 zjj. All rights reserved.
//

#import "ListCollModel.h"

@implementation ListCollModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        _littleData = [[NSMutableArray alloc]init];
    }
    return self;
}

@end
