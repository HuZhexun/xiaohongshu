//
//  MessageModel.h
//  小红书
//
//  Created by 李志文 on 16/2/16.
//  Copyright © 2016年 Javenlee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MessageModel : NSObject

@property (nonatomic,copy) NSString *desc;

@property (nonatomic,copy) NSString *imageUrl;

@property (nonatomic,copy) NSString *title;

@end
