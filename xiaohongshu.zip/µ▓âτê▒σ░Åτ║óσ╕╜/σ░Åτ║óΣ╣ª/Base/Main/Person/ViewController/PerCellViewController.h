//
//  PerCellViewController.h
//  小红书
//
//  Created by 李志文 on 16/2/23.
//  Copyright © 2016年 Javenlee. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NoteModel;

@interface PerCellViewController : UIViewController

@property (nonatomic,strong) NoteModel *noteModel;

@end
