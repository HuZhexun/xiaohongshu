//
//  DiscoverFifthCell.h
//  SmallBook
//
//  Created by Apple on 16/2/23.
//  Copyright © 2016年 胡哲逊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoverFifthCell : UITableViewCell

@property (nonatomic, copy) NSArray *data;
@property (nonatomic, copy) NSMutableArray *viewArr;
@end
