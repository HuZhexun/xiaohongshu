//
//  MainViewController.h
//  小红书
//
//  Created by 李志文 on 16/2/13.
//  Copyright © 2016年 Javenlee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UITabBarController


@end
